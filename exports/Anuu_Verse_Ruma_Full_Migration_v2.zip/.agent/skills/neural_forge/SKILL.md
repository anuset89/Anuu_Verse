---
name: neural_forge
description: usage of the forge.py tool for autonomous code refactoring.
---

# Neural Forge Skill

This skill documents how to use the `forge.py` tool to autonomously improve the codebase.

## Usage

### 1. Analysis
Check the complexity of a file without changing it:
```bash
python3 backend/forge/forge.py backend/main.py --dry-run
```

### 2. Refactoring
Apply "Titan-Level" improvements (Async, Types, Error Handling):
```bash
python3 backend/forge/forge.py backend/vram_orchestrator/vram_orchestrator.py --model codellama
```

### 3. Validation
The tool automatically runs AST validation. If it fails, check the logs:
```bash
cat forge.log
```

## Strategy
- Run Forge on new modules immediately after creation.
- Use `git diff` to review Forge changes before committing.
- Do not Forge `forge.py` itself (danger of recursion).
