---
name: git_mastery
description: Advanced Git workflows for managing the Anuu_Verse repository.
---

# Git Mastery Skill

This skill provides advanced workflows for managing the Anuu_Verse repository, ensuring clean history, proper branching, and safe merges.

## Workflows

### 1. Feature Branch Workflow
When starting a new feature (e.g., "M1-Anime-Director"):
```bash
git checkout -b feature/M1-anime-director
# ... work ...
git add .
git commit -m "feat(M1): initial scaffold for anime pipeline"
```

### 2. Emergency Hotfix
If `main` is broken:
```bash
git checkout main
git checkout -b hotfix/vram-leak
# ... fix ...
git commit -m "fix(lung): resolved vram OOM error"
git checkout main
git merge hotfix/vram-leak
```

### 3. Rebase Strategy
To keep history linear:
```bash
git fetch origin
git rebase origin/main
```

## Best Practices
- **Commit Messages**: Use Conventional Commits (`feat:`, `fix:`, `docs:`, `chore:`).
- **Atomic Commits**: One logical change per commit.
- **No Force Push**: Unless you are the only one on the branch.
