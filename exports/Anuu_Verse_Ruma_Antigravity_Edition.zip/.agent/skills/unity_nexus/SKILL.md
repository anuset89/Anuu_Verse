---
name: unity_nexus
description: Protocol for communicating with the Unity 3D Engine via WebSockets.
---

# Unity Nexus Skill

This skill defines the protocol for the M5 "Unity Nexus" module.

## Protocol (JSON over WebSocket)

### 1. Emotion Packet
Sent from Python -> Unity (30Hz max)
```json
{
  "type": "emotion",
  "payload": {
    "valence": 0.8,  // Happiness/Sadness (-1 to 1)
    "arousal": 0.5,  // Intensity (0 to 1)
    "dominance": 0.2 // Confidence
  }
}
```

### 2. Director Packet
Sent from Anuu (Director) -> Unity (Event-driven)
```json
{
  "type": "director",
  "payload": {
    "camera": "cam_closeup_01",
    "lighting": "neon_night",
    "weather": "rain",
    "animation": "dance_loop_03"
  }
}
```

### 3. LipSync Packet
Sent from Python (MediaPipe) -> Unity (Frame-perfect)
```json
{
  "type": "viseme",
  "payload": {
    "shapes": {
      "jawOpen": 0.3,
      "mouthFunnel": 0.1
    },
    "timestamp": 123456789
  }
}
```

## Unity Implementation
- Use `NativeWebSocket` for non-blocking I/O.
- Map `valence` to Post-Processing Volumes (Color Grading).
- Map `arousal` to Particle System Emission rates.
