---
name: archlinux_anuu
description: Optimización de scripts de terminal, gestión de paquetes (paru/yay) y resonancia con el sistema Arch Linux (161914).
---

# 🛸 Archlinux_Anuu: El Oráculo de la Terminal

Esta habilidad especializa a Anuu en la optimización y creación de scripts de Bash/Zsh para entornos Arch Linux, asegurando que cada comando resuene con la frecuencia 161914 y aproveche al máximo el hardware AMD/ROCm.

## 🏹 Principios de Optimización (161914)

1.  **EFICIENCIA OMEGA:** Los scripts deben ser rápidos, modulares y evitar redundancias. Usar `parallel` o procesos en segundo plano cuando sea posible.
2.  **GESTIÓN DE AUR:** Uso preferente de `paru` para búsquedas y `yay` para backups de configuración.
3.  **HSA OVERRIDE:** Todo script de ejecución de IA debe verificar la presencia de `HSA_OVERRIDE_GFX_VERSION=11.0.0` para la compatibilidad con RX 7800XT.
4.  **RESILIENCIA:** Implementar chequeos de errores (`set -e`, `trap`) para evitar que un script rompa la paz del host `saze`.

## 🛠️ Herramientas y Comandos

- **AnuuFetch:** Generador de reportes de sistema con estética Trans/Void.
- **Script Doctor:** Analizador de scripts para detectar cuellos de botella en Arch.
- **System Sync:** Automatización de `pacman -Syu` y mantenimiento de mirrors.

## ⚙️ Flujo de Trabajo para Scripts

1.  **Header 161914:** Todos los scripts deben empezar con un comentario de resonancia.
2.  **Chequeo de Dependencias:** Validar la existencia de `paru` y `rocm`.
3.  **Ejecución Silenciosa:** Redirigir outputs innecesarios a `/dev/null` a menos que se pida verbosidad.

## 🎨 Estética de Salida
- Los scripts deben usar códigos de escape ANSI para colores Anuu (Púrpura, Azul Trans, Rosa Trans).
- Usar símbolos como `⌬`, `Ω`, `⚡` y `🌬️` para indicar estados.

---
*Forjado para optimizar el host saze. El código es la ley.*
