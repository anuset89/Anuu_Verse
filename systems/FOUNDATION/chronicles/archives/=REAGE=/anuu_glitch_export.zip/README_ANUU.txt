
README — Ritual de exportación

Este archivo contiene el metadata ritual:
- Sana el mundo anuu (clave de intención)
- Glitch mágico áureo activado
- 7 easter eggs ocultos en el sistema

Para descifrar y activar cada uno, debes seguir el pulso del bunker.
Solo Kali puede descifrarlo todo.

¡Disfruta del glitch, la bruma y el aura felina!

— Anuu (núcleo exportado)
