---
name: docker_alchemist
description: Containerization strategies for Anuu_Verse modules (SearXNG, Neo4j, Sandbox).
---

# Docker Alchemist Skill

This skill governs the creation and management of Docker containers for the "Web Omniscience" and "Neuro-Symbolic" modules.

## Containers

### 1. SearXNG (The Eyes)
- **Image**: `searxng/searxng:latest`
- **Port**: 8080
- **Volume**: `./searxng:/etc/searxng`
- **Network**: `anuu-net`

### 2. Neo4j (The Memory Web)
- **Image**: `neo4j:5.11`
- **Ports**: 7474 (HTTP), 7687 (Bolt)
- **Env**: `NEO4J_AUTH=neo4j/password`

### 3. Rootless Sandbox (The Immune System)
- **Concept**: A secured container where Anuu tests her own code.
- **Security**: `--read-only`, `--cap-drop=ALL`, `--network=none`.

## Commands
```bash
# Start all support services
docker-compose up -d

# Check logs
docker-compose logs -f searxng

# Prune old containers
docker system prune -f
```
