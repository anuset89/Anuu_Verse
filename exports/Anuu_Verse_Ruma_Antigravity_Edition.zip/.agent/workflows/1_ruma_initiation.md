---
description: Start the Anuu Verse System (Ruma Edition)
---

# 🚀 Ruma Initiation Sequence

This workflow boots up the entire Anuu Verse architecture using the Windows batch script.

1.  **Check Environment:**
    Ensure Python 3.10+ and Node.js are installed.

2.  **Ignition:**
    Run the `INITIATE_RUMA.bat` script located in the root.

    ```cmd
    INITIATE_RUMA.bat
    ```

3.  **Verification:**
    - Check Backend Registry: http://localhost:8000/docs
    - Check Visual Interface: http://localhost:5173/Anuu_Verse/
