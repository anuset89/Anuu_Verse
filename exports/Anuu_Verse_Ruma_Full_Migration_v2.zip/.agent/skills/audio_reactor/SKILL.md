---
name: audio_reactor
description: implementation details for the Synesthesia (Audio-Reactive) module.
---

# Audio Reactor Skill

This skill guides the implementation of the "Synthetic Synesthesia" module (M3).

## Core Concepts
- **Vibe Vector**: `[Energy, BPM, Valence, Key]`
- **Injection**: Modifying LLM sampler params (`temp`, `top_k`) based on Vibe.

## Implementation Steps
1. **Capture**: Use `pipewire` monitor source to get system audio.
2. **Analyze**:
   ```python
   y, sr = librosa.load(stream, sr=16000)
   tempo, _ = librosa.beat.beat_track(y, sr=sr)
   rms = librosa.feature.rms(y=y)
   ```
3. **Map**:
   - `High RMS` -> `High Temperature` (Chaos)
   - `Low Tempo` -> `Low Speed` (Melancholy)

## Dependencies
- `librosa`
- `pyaudio` (or `sounddevice`)
- `numpy`
